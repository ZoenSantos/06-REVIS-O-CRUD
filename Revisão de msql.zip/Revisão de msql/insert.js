var mysql = require('mysql2');

var con = mysql.createConnection({
  host: "localhost",
  user: "phpmyadmin",
  password: "aluno",
  database: "revisao"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  var sql = "INSERT INTO customers (name, address) VALUES ('Sony pictures', 'Culver City')"; 
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");
  });
});